# app/__init__.py
# Make 'app' a proper Python package.
