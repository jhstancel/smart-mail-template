---
name: Bug report
about: Report a problem
---

**Describe the bug**
**Steps to reproduce**
**Expected behavior**
**Actual behavior**
**Environment (OS, Python)**

