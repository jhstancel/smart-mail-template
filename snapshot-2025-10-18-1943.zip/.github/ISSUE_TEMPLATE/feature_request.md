---
name: Feature request
about: Suggest an idea
---

**Problem**
**Proposed solution**
**Alternatives**
**Additional context**

