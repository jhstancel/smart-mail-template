## Summary
<!-- What does this PR change? -->

## Checklist
- [ ] Updated `configs/intents.json`
- [ ] Added/updated `templates/<intent>.j2`
- [ ] `make validate` passes
- [ ] `pytest -q` passes
- [ ] README updated (if user-visible change)
- [ ] (Optional) Added training examples + `make train` if Auto-Detect should recognize it

## Notes
<!-- Any follow-ups or caveats -->

